# OmniDisk

A local-first router that fragments files across multiple free-tier cloud
storage accounts, so your effective free space is the sum of every account
you connect.

This started as the **Phase 0 skeleton** — the local web app boots, the
metadata database and credential vault work, the priority manager and the
core fragmentation/routing algorithm are fully implemented and tested, and
the REST API + dashboard UI are wired end-to-end.

**Phase 1 is well underway:** three concrete `ProviderAccountBase`
adapters exist in `server/providers/` — `MegaAccount`, `GoogleDriveAccount`,
and `SupabaseAccount` — and are wired into `AccountRegistry` both at server
startup (accounts saved in a prior session reconnect automatically) and
immediately after a new account is added via `POST /api/providers/mega/accounts`,
`POST /api/providers/supabase/accounts`, or the Google Drive OAuth flow.
Every other provider in the catalog (OneDrive, Dropbox, Box, pCloud, GitHub,
GitLab, R2, B2, S3, Azure, GCS, WebDAV) still has no adapter, so accounts
for those remain "saved but not connected" exactly as before — see
`server/providers/adapter-factory.ts`, the single place that needs a new
`case` when the next adapter lands.

Google Drive's OAuth flow is fully real end-to-end, including the frontend:
`AddProviderModal` full-page-navigates the browser to the `consentUrl`
returned by `POST /api/providers/google_drive/connect`; Google redirects
back to `GET /api/providers/google_drive/oauth-callback` (a route on this
same server — see the setup guide for why the OAuth client must be a
**Web application** type, not Desktop, with that exact URI registered),
which exchanges the code, registers the live adapter, and redirects the
browser on to the dashboard.

Also worth knowing: `planAllocation` (in `fragment-router.ts`) now actually
enforces `maxSingleObjectBytes` — an account's allocation is split into
multiple ≤-cap fragments instead of one oversized one. This was a real gap
(the field existed on several registry entries but was never read) that
Supabase Storage's hard 50MB/file limit forced fixing properly rather than
working around per-adapter.

On top of that, the **provider registry & catalog UI** is fully built: a
data-driven "Add a provider" flow covering all 15 supported providers,
driven entirely by `server/core/provider-registry.ts` — no per-provider
form code. This includes the app-level vs. account-level credential split
(one Google Cloud app authorizes any number of Drive accounts), the
billed-provider guardrail (S3/Azure/GCS default to disabled), and the
credential vault's OS-keychain-with-encrypted-file-fallback. What's still
missing is the concrete adapter behind each provider — `connect`/`accounts`
register real DB rows and reserve credential slots, but there's no live
OAuth consent screen or API validation call yet, since that requires an
adapter to validate against.

## Open decisions this build assumed (spec section 15)

These were picked using the spec's own stated recommendations, since no
answer was given yet. Revisit `docs/OmniDisk_MasterSpec.md` §15 if you'd
rather go a different way:

1. **Local web app**, not Electron, for Phase 0/1.
2. **Raw `better-sqlite3`**, not an ORM, for the skeleton stage.
3. **Chunk size default: 8MB** (configurable in Settings).
4. First two provider adapters to build in Phase 1 are still open — nothing
   here depends on which two you pick.

## Project layout

```
server/          Fastify API, SQLite metadata store, core routing algorithm
  core/          models, fragment-router, priority-manager, compression,
                 provider-account-base (the adapter contract), account-registry,
                 provider-registry (the 15-provider catalog)
  db/            schema.sql, client.ts (AppData resolution + column migrations), repository.ts
  security/      credential-vault.ts (OS keychain / encrypted-file fallback)
  api/           Fastify server + route modules
  providers/     empty — concrete adapters land here in Phase 1
web/             Vite + React + Tailwind dashboard (Dashboard, File Explorer, Settings)
  src/components/ProviderCatalogGrid.tsx, DynamicProviderForm.tsx, AddProviderModal.tsx
                 — the catalog-driven "Add a provider" flow
tests/
  unit/          allocation algorithm, compression roundtrip, priority manager
  integration/   full upload -> fragment -> store -> retrieve -> download cycle,
                 provider catalog / app-config / connect / accounts routes
  helpers/       MockProviderAccount — in-memory adapter, no network calls
```

## Running it

```bash
npm install

# Terminal 1 — API server on http://127.0.0.1:4310
npm run dev:server

# Terminal 2 — dashboard on http://localhost:5173 (proxies /api to the server)
npm run dev:web
```

### Running it on Google Colab

See [`colab/README.md`](./colab/README.md) — a single self-contained script
(`colab/run_omnidisk_colab.py`) mounts Drive, installs everything, builds
the frontend, and serves the whole app (frontend + API, one port) behind a
Colab-provided public URL. This is also why `server/api/server.ts` can now
serve `web/dist` directly (`OMNIDISK_DATA_DIR` and `OMNIDISK_PUBLIC_URL` env
vars support this single-port, Drive-backed mode; both are no-ops for the
normal two-terminal local setup above).

## Running the tests

```bash
npm test
```

Covers the overflow-fill allocation algorithm (exact fit, multi-account
spillover, insufficient-space abort-before-network-call, capacity-exhausted
skip), compression roundtrips, priority-manager ranking across all four sort
modes, and a full mock-provider upload/download integration cycle with
checksum verification.

## What's next (Phase 1, continued)

`MegaAccount` and `GoogleDriveAccount` are done (see above). Remaining:

1. Wire `AddProviderModal`'s "Connect" button for Google Drive to open the
   returned `consentUrl` and run a local loopback listener on
   `127.0.0.1:53682/oauth/callback` that posts the `code` to
   `/api/providers/google_drive/oauth-callback`.
2. Add the next `S3CompatibleAccount` adapter (shared base for R2/B2/S3 —
   see provider-setup-guide.md §15) in `server/providers/`, plus a `case`
   for it in `adapter-factory.ts`. Nothing in the router, priority manager,
   or API routes needs to change — that boundary was the point of the
   skeleton, and still holds after two real adapters.
3. Credential rotation (Box/OneDrive's refresh-token-rotates-on-every-use
   behavior) isn't implemented in any adapter yet — MEGA and Google Drive
   don't need it, but it'll matter once those two adapters are built.

The one other stub worth flagging: the credential vault's "user passphrase
prompted once per session" (spec §9) has no session/first-run UI yet, so
the encrypted-file fallback currently uses a locally-generated key file
instead. Wiring in a real passphrase prompt is a drop-in swap.
