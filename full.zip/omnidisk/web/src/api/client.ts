// Thin typed wrapper around the REST API in server/api/routes.
// Mirrors server/core/models.ts — keep the two in sync.

export type CompressionAlgo = "none" | "zstd" | "gzip" | "brotli";
export type FragmentStatus = "pending" | "stored" | "failed";
export type FileStatus =
  | "pending"
  | "uploading"
  | "complete"
  | "partial"
  | "failed"
  | "deleted";
export type PrioritySortMode = "speed" | "latency" | "free_space" | "manual";
export type AuthType = "oauth2" | "api_key" | "basic";
export type ProviderFieldType = "text" | "password" | "url" | "select" | "number";

export interface FileFragment {
  fragmentId: string;
  fileUuid: string;
  providerName: string;
  accountIndex: number;
  byteStart: number;
  byteEnd: number;
  index: number;
  remotePath: string;
  checksum?: string;
  status: FragmentStatus;
  retryCount: number;
  lastError?: string;
}

export interface OmniFile {
  fileUuid: string;
  fileName: string;
  fileSize: number;
  compressedSize?: number;
  compressionUsed: CompressionAlgo;
  successfullyStoredSize: number;
  fileUploadDate: string;
  fragments?: FileFragment[];
  status: FileStatus;
  sha256Original?: string;
}

export interface ProviderFieldDef {
  key: string;
  label: string;
  type: ProviderFieldType;
  placeholder?: string;
  required: boolean;
  helpText?: string;
  options?: { value: string; label: string }[];
  default?: string | number;
  secret?: boolean;
}

export interface ProviderDefinition {
  providerName: string;
  displayName: string;
  logoUrl: string;
  authType: AuthType;
  freeTierLabel: string;
  liveQuotaSupported: boolean;
  maxSingleObjectBytes?: number;
  isBilledProvider: boolean;
  setupGuideAnchor: string;
  appLevelFields: ProviderFieldDef[];
  accountLevelFields: ProviderFieldDef[];
  requiresOAuthConnect: boolean;
}

export interface ProviderAccountRecord {
  providerName: string;
  accountIndex: number;
  label?: string;
  authType: AuthType;
  totalSpace?: number;
  usedSpace?: number;
  avgLatencyMs: number;
  avgSpeedBps: number;
  priorityScore: number;
  manualPriorityRank?: number;
  enabled: boolean;
  lastProbedAt?: string;
  isLiveQuota: boolean;
  isBilledProvider: boolean;
  configuredCapBytes?: number;
  maxSingleObjectBytes?: number;
  connected?: boolean;
}

export interface GlobalSettings {
  defaultCompression: CompressionAlgo;
  prioritySortMode: PrioritySortMode;
  chunkSizeBytes: number;
  retryMaxAttempts: number;
  stalenessThresholdMs: number;
}

export interface StatsPayload {
  totalSpace: number;
  totalUsed: number;
  totalFree: number;
  totalFragmentCount: number;
  totalFiles: number;
  filesByStatus: Record<string, number>;
  perProvider: {
    providerName: string;
    accountIndex: number;
    label?: string;
    freeSpace: number;
    usedSpace: number;
    fragmentCount: number;
    enabled: boolean;
  }[];
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const hasBody = init?.body !== undefined;
  const isFormData = init?.body instanceof FormData;
  const res = await fetch(`/api${path}`, {
    // Only declare JSON when we're actually sending a JSON body — sending
    // this header with no body (e.g. plain POSTs like retry) makes Fastify
    // reject the request as malformed JSON before our route code ever runs,
    // which is why errors from those calls used to show up as a bare,
    // unhelpful "Bad Request".
    headers: hasBody && !isFormData ? { "Content-Type": "application/json" } : undefined,
    ...init,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(body.error ?? `Request to ${path} failed with ${res.status}`);
  }
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

export const api = {
  providers: {
    // -- catalog (provider types) --
    catalog: () => request<ProviderDefinition[]>("/providers/catalog"),
    getAppConfigStatus: (providerName: string) =>
      request<{ configured: boolean }>(`/providers/catalog/${providerName}/app-config`),
    saveAppConfig: (providerName: string, fields: Record<string, string | number | boolean>) =>
      request<{ saved: true }>(`/providers/catalog/${providerName}/app-config`, {
        method: "POST",
        body: JSON.stringify(fields),
      }),

    // -- account instances --
    listAccounts: () => request<ProviderAccountRecord[]>("/providers/accounts"),
    connect: (providerName: string, accountFields: Record<string, string | number | boolean>) =>
      request<{ providerName: string; accountIndex: number; label?: string }>(
        `/providers/${providerName}/connect`,
        { method: "POST", body: JSON.stringify(accountFields) },
      ),
    createAccount: (providerName: string, accountFields: Record<string, string | number | boolean>) =>
      request<{ providerName: string; accountIndex: number; label?: string }>(
        `/providers/${providerName}/accounts`,
        { method: "POST", body: JSON.stringify(accountFields) },
      ),
    patchAccount: (providerName: string, accountIndex: number, patch: Partial<ProviderAccountRecord>) =>
      request<ProviderAccountRecord>(`/providers/accounts/${providerName}/${accountIndex}`, {
        method: "PATCH",
        body: JSON.stringify(patch),
      }),
    removeAccount: (providerName: string, accountIndex: number) =>
      request<void>(`/providers/accounts/${providerName}/${accountIndex}`, { method: "DELETE" }),
    refreshPriority: (mode?: PrioritySortMode) =>
      request<ProviderAccountRecord[]>("/providers/refresh-priority", {
        method: "POST",
        body: JSON.stringify({ mode }),
      }),
  },
  files: {
    list: (status?: FileStatus) =>
      request<OmniFile[]>(`/files${status ? `?status=${status}` : ""}`),
    get: (fileUuid: string) => request<OmniFile>(`/files/${fileUuid}`),
    remove: (fileUuid: string) => request<void>(`/files/${fileUuid}`, { method: "DELETE" }),
    retry: (fileUuid: string) => request<OmniFile>(`/files/${fileUuid}/retry`, { method: "POST" }),
    downloadUrl: (fileUuid: string) => `/api/files/${fileUuid}/download`,
    upload: async (file: File, compression?: CompressionAlgo): Promise<OmniFile> => {
      const form = new FormData();
      form.append("file", file);
      if (compression) form.append("compression", compression);
      return request<OmniFile>("/files/upload", { method: "POST", body: form });
    },
  },
  stats: {
    get: () => request<StatsPayload>("/stats"),
  },
  settings: {
    get: () => request<GlobalSettings>("/settings"),
    patch: (patch: Partial<GlobalSettings>) =>
      request<GlobalSettings>("/settings", { method: "PATCH", body: JSON.stringify(patch) }),
    vaultStatus: () => request<{ backend: "os_keychain" | "encrypted_file" }>("/settings/vault-status"),
  },
};
