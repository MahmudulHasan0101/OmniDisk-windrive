import Database from "better-sqlite3";
import envPaths from "env-paths";
import { mkdirSync, readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));

/**
 * AppData layout, per spec section 4:
 *
 * <AppData>/OmniDisk/
 * ├── omnidisk.db
 * ├── credentials.enc
 * ├── config.json
 * ├── cache/tmp_uploads/
 * └── logs/omnidisk.log
 *
 * Nothing related to file content or credentials is ever written outside
 * this folder.
 */
export const paths = envPaths("OmniDisk", { suffix: "" });

export const APPDATA_DIR = paths.data;
export const DB_PATH = join(APPDATA_DIR, "omnidisk.db");
export const CREDENTIALS_PATH = join(APPDATA_DIR, "credentials.enc");
export const CONFIG_PATH = join(APPDATA_DIR, "config.json");
export const CACHE_DIR = join(APPDATA_DIR, "cache");
export const TMP_UPLOADS_DIR = join(CACHE_DIR, "tmp_uploads");
export const LOGS_DIR = join(APPDATA_DIR, "logs");
export const LOG_FILE = join(LOGS_DIR, "omnidisk.log");

function ensureAppDataLayout(): void {
  mkdirSync(APPDATA_DIR, { recursive: true });
  mkdirSync(TMP_UPLOADS_DIR, { recursive: true });
  mkdirSync(LOGS_DIR, { recursive: true });
}

/**
 * `CREATE TABLE IF NOT EXISTS` in schema.sql only covers brand-new tables —
 * it silently no-ops on a table that already exists with an older column
 * set, which is exactly what happens to a database created before a schema
 * addition (e.g. an existing install upgrading to the provider registry's
 * new provider_accounts columns). This adds any missing columns in place
 * rather than requiring a manual reset. A dedicated migrations/ folder
 * with numbered steps is the natural next evolution once schema changes
 * get more involved than "add a column with a default".
 */
function runColumnMigrations(db: Database.Database): void {
  const existingColumns = new Set(
    (db.prepare("PRAGMA table_info(provider_accounts)").all() as { name: string }[]).map(
      (c) => c.name,
    ),
  );

  const columnsToEnsure: { name: string; ddl: string }[] = [
    { name: "is_live_quota", ddl: "ALTER TABLE provider_accounts ADD COLUMN is_live_quota INTEGER NOT NULL DEFAULT 1" },
    { name: "is_billed_provider", ddl: "ALTER TABLE provider_accounts ADD COLUMN is_billed_provider INTEGER NOT NULL DEFAULT 0" },
    { name: "configured_cap_bytes", ddl: "ALTER TABLE provider_accounts ADD COLUMN configured_cap_bytes INTEGER" },
    { name: "max_single_object_bytes", ddl: "ALTER TABLE provider_accounts ADD COLUMN max_single_object_bytes INTEGER" },
  ];

  for (const { name, ddl } of columnsToEnsure) {
    if (!existingColumns.has(name)) db.exec(ddl);
  }
}

let dbInstance: Database.Database | null = null;

/**
 * Returns a singleton, lazily-initialized SQLite connection with the
 * schema applied (idempotent — every statement in schema.sql is
 * CREATE ... IF NOT EXISTS) plus any pending column migrations.
 */
export function getDb(): Database.Database {
  if (dbInstance) return dbInstance;

  ensureAppDataLayout();

  const db = new Database(DB_PATH);
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");

  const schemaPath = join(__dirname, "schema.sql");
  const schema = readFileSync(schemaPath, "utf-8");
  db.exec(schema);
  runColumnMigrations(db);

  dbInstance = db;
  return db;
}

/** Test/dev helper: use an isolated in-memory database instead of AppData. */
export function createInMemoryDb(): Database.Database {
  const db = new Database(":memory:");
  db.pragma("foreign_keys = ON");
  const schemaPath = join(__dirname, "schema.sql");
  const schema = readFileSync(schemaPath, "utf-8");
  db.exec(schema);
  runColumnMigrations(db);
  return db;
}

export function closeDb(): void {
  dbInstance?.close();
  dbInstance = null;
}
