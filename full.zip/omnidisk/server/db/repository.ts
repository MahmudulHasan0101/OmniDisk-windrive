import type Database from "better-sqlite3";
import type {
  OmniFile,
  FileFragment,
  ProviderAccountRecord,
  ProviderAppConfigRecord,
  GlobalSettings,
} from "../core/models.js";
import { DEFAULT_SETTINGS } from "../core/models.js";

// ---------------------------------------------------------------------------
// Row <-> model mapping (snake_case columns <-> camelCase TS fields)
// ---------------------------------------------------------------------------

interface FileRow {
  file_uuid: string;
  file_name: string;
  file_size: number;
  compressed_size: number | null;
  compression_used: OmniFile["compressionUsed"];
  successfully_stored_size: number;
  file_upload_date: string;
  status: OmniFile["status"];
  sha256_original: string | null;
}

interface FragmentRow {
  fragment_id: string;
  file_uuid: string;
  provider_name: string;
  account_index: number;
  byte_start: number;
  byte_end: number;
  frag_index: number;
  remote_path: string;
  checksum: string | null;
  status: FileFragment["status"];
  retry_count: number;
  last_error: string | null;
}

interface ProviderAccountRow {
  provider_name: string;
  account_index: number;
  label: string | null;
  base_url: string | null;
  auth_type: ProviderAccountRecord["authType"];
  credential_ref: string;
  total_space: number | null;
  used_space: number | null;
  avg_latency_ms: number;
  avg_speed_bps: number;
  priority_score: number;
  manual_priority_rank: number | null;
  enabled: number;
  last_probed_at: string | null;
  is_live_quota: number;
  is_billed_provider: number;
  configured_cap_bytes: number | null;
  max_single_object_bytes: number | null;
}

function fragmentRowToModel(row: FragmentRow): FileFragment {
  return {
    fragmentId: row.fragment_id,
    fileUuid: row.file_uuid,
    providerName: row.provider_name,
    accountIndex: row.account_index,
    byteStart: row.byte_start,
    byteEnd: row.byte_end,
    index: row.frag_index,
    remotePath: row.remote_path,
    checksum: row.checksum ?? undefined,
    status: row.status,
    retryCount: row.retry_count,
    lastError: row.last_error ?? undefined,
  };
}

function providerRowToModel(row: ProviderAccountRow): ProviderAccountRecord {
  return {
    providerName: row.provider_name,
    accountIndex: row.account_index,
    label: row.label ?? undefined,
    baseUrl: row.base_url ?? undefined,
    authType: row.auth_type,
    credentialRef: row.credential_ref,
    totalSpace: row.total_space ?? undefined,
    usedSpace: row.used_space ?? undefined,
    avgLatencyMs: row.avg_latency_ms,
    avgSpeedBps: row.avg_speed_bps,
    priorityScore: row.priority_score,
    manualPriorityRank: row.manual_priority_rank ?? undefined,
    enabled: row.enabled === 1,
    lastProbedAt: row.last_probed_at ?? undefined,
    isLiveQuota: row.is_live_quota === 1,
    isBilledProvider: row.is_billed_provider === 1,
    configuredCapBytes: row.configured_cap_bytes ?? undefined,
    maxSingleObjectBytes: row.max_single_object_bytes ?? undefined,
  };
}

// ---------------------------------------------------------------------------
// Files + fragments
// ---------------------------------------------------------------------------

export class FileRepository {
  constructor(private db: Database.Database) {}

  upsertFile(file: Omit<OmniFile, "fragments">): void {
    this.db
      .prepare(
        `INSERT INTO files (file_uuid, file_name, file_size, compressed_size,
           compression_used, successfully_stored_size, file_upload_date, status, sha256_original)
         VALUES (@fileUuid, @fileName, @fileSize, @compressedSize,
           @compressionUsed, @successfullyStoredSize, @fileUploadDate, @status, @sha256Original)
         ON CONFLICT(file_uuid) DO UPDATE SET
           file_name = excluded.file_name,
           compressed_size = excluded.compressed_size,
           compression_used = excluded.compression_used,
           successfully_stored_size = excluded.successfully_stored_size,
           status = excluded.status,
           sha256_original = excluded.sha256_original`,
      )
      .run({
        fileUuid: file.fileUuid,
        fileName: file.fileName,
        fileSize: file.fileSize,
        compressedSize: file.compressedSize ?? null,
        compressionUsed: file.compressionUsed,
        successfullyStoredSize: file.successfullyStoredSize,
        fileUploadDate: file.fileUploadDate,
        status: file.status,
        sha256Original: file.sha256Original ?? null,
      });
  }

  upsertFragment(fragment: FileFragment): void {
    this.db
      .prepare(
        `INSERT INTO file_fragments (fragment_id, file_uuid, provider_name, account_index,
           byte_start, byte_end, frag_index, remote_path, checksum, status, retry_count, last_error)
         VALUES (@fragmentId, @fileUuid, @providerName, @accountIndex,
           @byteStart, @byteEnd, @index, @remotePath, @checksum, @status, @retryCount, @lastError)
         ON CONFLICT(fragment_id) DO UPDATE SET
           checksum = excluded.checksum,
           status = excluded.status,
           retry_count = excluded.retry_count,
           last_error = excluded.last_error`,
      )
      .run({
        fragmentId: fragment.fragmentId,
        fileUuid: fragment.fileUuid,
        providerName: fragment.providerName,
        accountIndex: fragment.accountIndex,
        byteStart: fragment.byteStart,
        byteEnd: fragment.byteEnd,
        index: fragment.index,
        remotePath: fragment.remotePath,
        checksum: fragment.checksum ?? null,
        status: fragment.status,
        retryCount: fragment.retryCount,
        lastError: fragment.lastError ?? null,
      });
  }

  getFile(fileUuid: string): OmniFile | null {
    const row = this.db
      .prepare("SELECT * FROM files WHERE file_uuid = ?")
      .get(fileUuid) as FileRow | undefined;
    if (!row) return null;

    const fragmentRows = this.db
      .prepare(
        "SELECT * FROM file_fragments WHERE file_uuid = ? ORDER BY frag_index ASC",
      )
      .all(fileUuid) as FragmentRow[];

    return {
      fileUuid: row.file_uuid,
      fileName: row.file_name,
      fileSize: row.file_size,
      compressedSize: row.compressed_size ?? undefined,
      compressionUsed: row.compression_used,
      successfullyStoredSize: row.successfully_stored_size,
      fileUploadDate: row.file_upload_date,
      status: row.status,
      sha256Original: row.sha256_original ?? undefined,
      fragments: fragmentRows.map(fragmentRowToModel),
    };
  }

  listFiles(status?: OmniFile["status"]): Omit<OmniFile, "fragments">[] {
    const rows = status
      ? (this.db
          .prepare("SELECT * FROM files WHERE status = ? ORDER BY file_upload_date DESC")
          .all(status) as FileRow[])
      : (this.db
          .prepare("SELECT * FROM files ORDER BY file_upload_date DESC")
          .all() as FileRow[]);

    return rows.map((row) => ({
      fileUuid: row.file_uuid,
      fileName: row.file_name,
      fileSize: row.file_size,
      compressedSize: row.compressed_size ?? undefined,
      compressionUsed: row.compression_used,
      successfullyStoredSize: row.successfully_stored_size,
      fileUploadDate: row.file_upload_date,
      status: row.status,
      sha256Original: row.sha256_original ?? undefined,
    }));
  }

  deleteFile(fileUuid: string): void {
    // ON DELETE CASCADE removes file_fragments rows too.
    this.db.prepare("DELETE FROM files WHERE file_uuid = ?").run(fileUuid);
  }
}

// ---------------------------------------------------------------------------
// Provider accounts
// ---------------------------------------------------------------------------

export class ProviderAccountRepository {
  constructor(private db: Database.Database) {}

  upsert(account: ProviderAccountRecord): void {
    this.db
      .prepare(
        `INSERT INTO provider_accounts (provider_name, account_index, label, base_url,
           auth_type, credential_ref, total_space, used_space, avg_latency_ms, avg_speed_bps,
           priority_score, manual_priority_rank, enabled, last_probed_at,
           is_live_quota, is_billed_provider, configured_cap_bytes, max_single_object_bytes)
         VALUES (@providerName, @accountIndex, @label, @baseUrl, @authType, @credentialRef,
           @totalSpace, @usedSpace, @avgLatencyMs, @avgSpeedBps, @priorityScore,
           @manualPriorityRank, @enabled, @lastProbedAt,
           @isLiveQuota, @isBilledProvider, @configuredCapBytes, @maxSingleObjectBytes)
         ON CONFLICT(provider_name, account_index) DO UPDATE SET
           label = excluded.label,
           total_space = excluded.total_space,
           used_space = excluded.used_space,
           avg_latency_ms = excluded.avg_latency_ms,
           avg_speed_bps = excluded.avg_speed_bps,
           priority_score = excluded.priority_score,
           manual_priority_rank = excluded.manual_priority_rank,
           enabled = excluded.enabled,
           last_probed_at = excluded.last_probed_at,
           configured_cap_bytes = excluded.configured_cap_bytes`,
      )
      .run({
        providerName: account.providerName,
        accountIndex: account.accountIndex,
        label: account.label ?? null,
        baseUrl: account.baseUrl ?? null,
        authType: account.authType,
        credentialRef: account.credentialRef,
        totalSpace: account.totalSpace ?? null,
        usedSpace: account.usedSpace ?? null,
        avgLatencyMs: account.avgLatencyMs,
        avgSpeedBps: account.avgSpeedBps,
        priorityScore: account.priorityScore,
        manualPriorityRank: account.manualPriorityRank ?? null,
        enabled: account.enabled ? 1 : 0,
        lastProbedAt: account.lastProbedAt ?? null,
        isLiveQuota: account.isLiveQuota ? 1 : 0,
        isBilledProvider: account.isBilledProvider ? 1 : 0,
        configuredCapBytes: account.configuredCapBytes ?? null,
        maxSingleObjectBytes: account.maxSingleObjectBytes ?? null,
      });
  }

  list(): ProviderAccountRecord[] {
    const rows = this.db
      .prepare("SELECT * FROM provider_accounts ORDER BY priority_score DESC")
      .all() as ProviderAccountRow[];
    return rows.map(providerRowToModel);
  }

  get(providerName: string, accountIndex: number): ProviderAccountRecord | null {
    const row = this.db
      .prepare(
        "SELECT * FROM provider_accounts WHERE provider_name = ? AND account_index = ?",
      )
      .get(providerName, accountIndex) as ProviderAccountRow | undefined;
    return row ? providerRowToModel(row) : null;
  }

  /** Blocked at the API layer unless the account has no referencing fragments. */
  hasFragments(providerName: string, accountIndex: number): boolean {
    const row = this.db
      .prepare(
        "SELECT COUNT(*) AS n FROM file_fragments WHERE provider_name = ? AND account_index = ?",
      )
      .get(providerName, accountIndex) as { n: number };
    return row.n > 0;
  }

  delete(providerName: string, accountIndex: number): void {
    this.db
      .prepare(
        "DELETE FROM provider_accounts WHERE provider_name = ? AND account_index = ?",
      )
      .run(providerName, accountIndex);
  }
}

// ---------------------------------------------------------------------------
// Provider app-level configs (shared OAuth client_id/secret per provider type)
// ---------------------------------------------------------------------------

export class ProviderAppConfigRepository {
  constructor(private db: Database.Database) {}

  get(providerName: string): ProviderAppConfigRecord | null {
    const row = this.db
      .prepare("SELECT * FROM provider_app_configs WHERE provider_name = ?")
      .get(providerName) as
      | { provider_name: string; credential_ref: string; created_at: string }
      | undefined;
    if (!row) return null;
    return {
      providerName: row.provider_name,
      credentialRef: row.credential_ref,
      createdAt: row.created_at,
    };
  }

  exists(providerName: string): boolean {
    return this.get(providerName) !== null;
  }

  upsert(providerName: string, credentialRef: string): ProviderAppConfigRecord {
    const createdAt = new Date().toISOString();
    this.db
      .prepare(
        `INSERT INTO provider_app_configs (provider_name, credential_ref, created_at)
         VALUES (@providerName, @credentialRef, @createdAt)
         ON CONFLICT(provider_name) DO UPDATE SET credential_ref = excluded.credential_ref`,
      )
      .run({ providerName, credentialRef, createdAt });
    return { providerName, credentialRef, createdAt };
  }

  delete(providerName: string): void {
    this.db.prepare("DELETE FROM provider_app_configs WHERE provider_name = ?").run(providerName);
  }
}

// ---------------------------------------------------------------------------
// Settings (key/value, seeded with defaults)
// ---------------------------------------------------------------------------

export class SettingsRepository {
  constructor(private db: Database.Database) {}

  get(): GlobalSettings {
    const rows = this.db.prepare("SELECT key, value FROM settings").all() as {
      key: string;
      value: string;
    }[];
    const stored = Object.fromEntries(rows.map((r) => [r.key, r.value]));

    return {
      defaultCompression:
        (stored.default_compression as GlobalSettings["defaultCompression"]) ??
        DEFAULT_SETTINGS.defaultCompression,
      prioritySortMode:
        (stored.priority_sort_mode as GlobalSettings["prioritySortMode"]) ??
        DEFAULT_SETTINGS.prioritySortMode,
      chunkSizeBytes: stored.chunk_size_bytes
        ? Number(stored.chunk_size_bytes)
        : DEFAULT_SETTINGS.chunkSizeBytes,
      retryMaxAttempts: stored.retry_max_attempts
        ? Number(stored.retry_max_attempts)
        : DEFAULT_SETTINGS.retryMaxAttempts,
      stalenessThresholdMs: stored.staleness_threshold_ms
        ? Number(stored.staleness_threshold_ms)
        : DEFAULT_SETTINGS.stalenessThresholdMs,
    };
  }

  update(partial: Partial<GlobalSettings>): GlobalSettings {
    const current = this.get();
    const next = { ...current, ...partial };

    const rows: [string, string][] = [
      ["default_compression", next.defaultCompression],
      ["priority_sort_mode", next.prioritySortMode],
      ["chunk_size_bytes", String(next.chunkSizeBytes)],
      ["retry_max_attempts", String(next.retryMaxAttempts)],
      ["staleness_threshold_ms", String(next.stalenessThresholdMs)],
    ];

    const stmt = this.db.prepare(
      `INSERT INTO settings (key, value) VALUES (?, ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
    );
    const tx = this.db.transaction((entries: [string, string][]) => {
      for (const [key, value] of entries) stmt.run(key, value);
    });
    tx(rows);

    return next;
  }
}
