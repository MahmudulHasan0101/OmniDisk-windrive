-- OmniDisk metadata schema. Lives at <AppData>/OmniDisk/omnidisk.db
-- Never stores file content or credentials in plaintext — see security/credential-vault.ts.

CREATE TABLE IF NOT EXISTS files (
  file_uuid TEXT PRIMARY KEY,
  file_name TEXT NOT NULL,
  file_size INTEGER NOT NULL,
  compressed_size INTEGER,
  compression_used TEXT NOT NULL DEFAULT 'none',
  successfully_stored_size INTEGER NOT NULL DEFAULT 0,
  file_upload_date TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  sha256_original TEXT
);

-- One row per PROVIDER TYPE, only for OAuth2 providers (google_drive, onedrive,
-- dropbox, box, pcloud). Holds the developer-console "app" credentials
-- (client_id/secret) that are shared across every account instance of that
-- provider. Entered once via POST /providers/catalog/:providerName/app-config.
CREATE TABLE IF NOT EXISTS provider_app_configs (
  provider_name TEXT PRIMARY KEY,
  credential_ref TEXT NOT NULL,     -- key into credentials.enc / keytar entry name holding client_id+client_secret(+tenantId)
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS provider_accounts (
  provider_name TEXT NOT NULL,
  account_index INTEGER NOT NULL,
  label TEXT,
  base_url TEXT,
  auth_type TEXT NOT NULL,          -- oauth2 | api_key | basic
  credential_ref TEXT NOT NULL,     -- key into credentials.enc / keytar entry name
  total_space INTEGER,
  used_space INTEGER,
  avg_latency_ms REAL DEFAULT 0,
  avg_speed_bps REAL DEFAULT 0,
  priority_score REAL DEFAULT 0,
  manual_priority_rank INTEGER,     -- used only when sort mode = manual
  enabled INTEGER NOT NULL DEFAULT 1,
  last_probed_at TEXT,
  is_live_quota INTEGER NOT NULL DEFAULT 1,      -- mirrors ProviderDefinition.liveQuotaSupported
  is_billed_provider INTEGER NOT NULL DEFAULT 0, -- mirrors ProviderDefinition.isBilledProvider; billed accounts default enabled=0
  configured_cap_bytes INTEGER,      -- user-set ceiling, used instead of a live probe when is_live_quota = 0
  max_single_object_bytes INTEGER,   -- e.g. Box 250_000_000, GitHub 90_000_000; null = no cap
  PRIMARY KEY (provider_name, account_index)
);
-- NOTE: rows where auth_type = 'oauth2' should have a matching provider_app_configs
-- row for the same provider_name; rows where auth_type = 'api_key' or 'basic' have
-- no app_configs counterpart by design. This relationship is enforced in
-- application code at account-creation time rather than as a SQL foreign key,
-- since it's conditional on auth_type.

CREATE TABLE IF NOT EXISTS file_fragments (
  fragment_id TEXT PRIMARY KEY,
  file_uuid TEXT NOT NULL REFERENCES files(file_uuid) ON DELETE CASCADE,
  provider_name TEXT NOT NULL,
  account_index INTEGER NOT NULL,
  byte_start INTEGER NOT NULL,
  byte_end INTEGER NOT NULL,
  frag_index INTEGER NOT NULL,
  remote_path TEXT NOT NULL,
  checksum TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  retry_count INTEGER NOT NULL DEFAULT 0,
  last_error TEXT,
  FOREIGN KEY (provider_name, account_index) REFERENCES provider_accounts(provider_name, account_index)
);

CREATE INDEX IF NOT EXISTS idx_fragments_file ON file_fragments(file_uuid);
CREATE INDEX IF NOT EXISTS idx_fragments_account ON file_fragments(provider_name, account_index);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
-- rows: default_compression, priority_sort_mode, chunk_size_bytes, retry_max_attempts, etc.
