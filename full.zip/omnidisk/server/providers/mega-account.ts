import { Storage } from "megajs";
import { ProviderAccountBase } from "../core/provider-account-base.js";
import type { FileFragment, ProviderAccountIdentity } from "../core/models.js";

export interface MegaAccountConfig {
  accountIndex: number;
  label?: string;
  email: string;
  password: string;
}

/**
 * First concrete Phase 1 adapter — see provider-setup-guide.md §6.
 * MEGA has no OAuth/app-registration step: the SDK derives a session
 * straight from email+password (its own crypto login scheme), so this
 * is the simplest provider to stand up end-to-end.
 *
 * Fragments are stored flat in a dedicated "OmniDisk_Fragments" folder,
 * created lazily on first use, named by `remotePath` (which already
 * embeds fileUuid/provider/accountIndex — see FileFragment in models.ts).
 */
export class MegaAccount extends ProviderAccountBase {
  readonly identity: ProviderAccountIdentity;
  readonly baseUrl = "https://mega.nz";

  private readonly email: string;
  private readonly password: string;
  private storage: InstanceType<typeof Storage> | undefined;
  private readyPromise: Promise<InstanceType<typeof Storage>> | undefined;
  private static readonly FOLDER_NAME = "OmniDisk_Fragments";

  constructor(config: MegaAccountConfig) {
    super();
    this.identity = {
      providerName: "mega",
      accountIndex: config.accountIndex,
      label: config.label,
    };
    this.email = config.email;
    this.password = config.password;
  }

  /** Logs in once, lazily, and caches the ready `Storage` instance. */
  private async getStorage(): Promise<InstanceType<typeof Storage>> {
    if (this.storage) return this.storage;
    if (!this.readyPromise) {
      this.readyPromise = new Storage({
        email: this.email,
        password: this.password,
      }).ready.then((storage) => {
        this.storage = storage;
        return storage;
      });
    }
    return this.readyPromise;
  }

  /** Finds (or creates) the dedicated OmniDisk folder, cached per session. */
  private async getFragmentsFolder(): Promise<InstanceType<typeof Storage>["root"]> {
    const storage = await this.getStorage();
    const existing = storage.root.children?.find(
      (node) => node.name === MegaAccount.FOLDER_NAME && node.directory,
    );
    if (existing) return existing as unknown as InstanceType<typeof Storage>["root"];
    return new Promise((resolve, reject) => {
      storage.mkdir(MegaAccount.FOLDER_NAME, (err: Error | null, folder: unknown) => {
        if (err) reject(err);
        else resolve(folder as InstanceType<typeof Storage>["root"]);
      });
    });
  }

  private findFragmentFile(
    folder: InstanceType<typeof Storage>["root"],
    remotePath: string,
  ) {
    return folder.children?.find((node) => node.name === remotePath);
  }

  async getStorableSpace(): Promise<number> {
    const storage = await this.getStorage();
    // megajs only populates spaceUsed/spaceTotal via an explicit
    // getAccountInfo() call (`a: "uq"` under the hood) — plain login does
    // NOT fetch quota, so reading these right after `ready` silently gives
    // 0/0. Always ask for fresh account info here.
    const info = await storage.getAccountInfo();
    const total = info.spaceTotal ?? 0;
    const used = info.spaceUsed ?? 0;
    return Math.max(0, total - used);
  }

  async getStats(): Promise<import("../core/models.js").ProviderAccountStats> {
    const storage = await this.getStorage();
    const info = await storage.getAccountInfo();
    const total = info.spaceTotal ?? 0;
    const used = info.spaceUsed ?? 0;
    return {
      totalSpace: total,
      usedSpace: used,
      freeSpace: Math.max(0, total - used),
      fragmentCount: 0, // filled from DB aggregate by the caller, not here
      avgLatencyMs: 0,
      avgSpeedBps: 0,
      lastProbedAt: new Date().toISOString(),
      priorityScore: this.priorityScore,
      enabled: this.enabled,
    };
  }

  async store(fragment: FileFragment, data: Buffer): Promise<FileFragment> {
    const folder = await this.getFragmentsFolder();
    await new Promise<void>((resolve, reject) => {
      folder.upload(
        { name: fragment.remotePath, size: data.length },
        data,
        (err: Error | null) => (err ? reject(err) : resolve()),
      );
    });
    return fragment;
  }

  async retrieve(fragment: FileFragment): Promise<Buffer> {
    const folder = await this.getFragmentsFolder();
    const file = this.findFragmentFile(folder, fragment.remotePath);
    if (!file) throw new Error(`No fragment found at ${fragment.remotePath} in MEGA`);
    return file.downloadBuffer({});
  }

  async delete(fragment: FileFragment): Promise<void> {
    const folder = await this.getFragmentsFolder();
    const file = this.findFragmentFile(folder, fragment.remotePath);
    if (!file) return; // already gone — delete is idempotent
    await file.delete();
  }

  async pingLatency(): Promise<number> {
    const start = Date.now();
    await this.getStorage(); // cheap once session is warm; full login cost only on first call
    return Date.now() - start;
  }

  async measureThroughput(): Promise<number> {
    // Small 64KB sample upload/download, per spec §7 throughput probing.
    // MEGA's client-side encryption adds overhead vs raw network speed —
    // see provider-setup-guide.md §6 quirks — so this genuinely reflects
    // MEGA's effective speed, not just link speed.
    const sample = Buffer.alloc(64 * 1024, 1);
    const probeFragment: FileFragment = {
      fragmentId: `__probe_${this.identity.accountIndex}`,
      fileUuid: "__probe",
      providerName: "mega",
      accountIndex: this.identity.accountIndex,
      byteStart: 0,
      byteEnd: sample.length,
      index: 0,
      remotePath: `__omnidisk_probe_${Date.now()}`,
      status: "pending",
      retryCount: 0,
    };
    const start = Date.now();
    await this.store(probeFragment, sample);
    const elapsedMs = Date.now() - start;
    await this.delete(probeFragment).catch(() => {});
    return elapsedMs > 0 ? Math.round((sample.length / elapsedMs) * 1000) : sample.length;
  }
}
