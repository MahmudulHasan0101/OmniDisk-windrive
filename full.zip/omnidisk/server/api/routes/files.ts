import type { FastifyInstance } from "fastify";
import { createHash, randomUUID } from "node:crypto";
import { createWriteStream } from "node:fs";
import { readFile, rm } from "node:fs/promises";
import { pipeline } from "node:stream/promises";
import { join } from "node:path";
import { z } from "zod";
import { getDb, TMP_UPLOADS_DIR } from "../../db/client.js";
import { FileRepository, ProviderAccountRepository, SettingsRepository } from "../../db/repository.js";
import {
  planAllocation,
  segmentsToFragments,
  storeFragments,
  retryFailedFragments,
  retrieveFragmentsInOrder,
  verifyIntegrity,
} from "../../core/fragment-router.js";
import { compress, decompress } from "../../core/compression.js";
import type { CompressionAlgo, OmniFile } from "../../core/models.js";
import type { AccountRegistry } from "../../core/account-registry.js";
import type { PriorityManager } from "../../core/priority-manager.js";
import { progressBus } from "../progress-bus.js";

const compressionOverrideSchema = z.enum(["none", "zstd", "gzip", "brotli"]).optional();

export function registerFileRoutes(
  app: FastifyInstance,
  deps: { registry: AccountRegistry; priorityManager: PriorityManager },
): void {
  const db = getDb();
  const fileRepo = new FileRepository(db);
  const providerRepo = new ProviderAccountRepository(db);
  const settingsRepo = new SettingsRepository(db);

  // GET /files — list all files with progress/status (fragments omitted)
  app.get<{ Querystring: { status?: OmniFile["status"]; sort?: string } }>(
    "/api/files",
    async (request) => {
      return fileRepo.listFiles(request.query.status);
    },
  );

  // GET /files/:fileUuid — file detail incl. full fragment map
  app.get<{ Params: { fileUuid: string } }>(
    "/api/files/:fileUuid",
    async (request, reply) => {
      const file = fileRepo.getFile(request.params.fileUuid);
      if (!file) return reply.code(404).send({ error: "File not found" });
      return file;
    },
  );

  // GET /files/:fileUuid/progress — SSE stream of per-fragment status updates
  app.get<{ Params: { fileUuid: string } }>(
    "/api/files/:fileUuid/progress",
    async (request, reply) => {
      const { fileUuid } = request.params;

      reply.raw.writeHead(200, {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
      });

      const unsubscribe = progressBus.subscribe(fileUuid, (fragment) => {
        reply.raw.write(`data: ${JSON.stringify(fragment)}\n\n`);
      });

      request.raw.on("close", unsubscribe);
    },
  );

  // POST /files/upload — stage, compress, fragment, and route a new file
  app.post("/api/files/upload", async (request, reply) => {
    // Fail fast with a clear reason before touching the multipart body at
    // all: if nothing has a live connection, there's nowhere to route this
    // file regardless of its size. This is distinct from a genuine
    // insufficient-space case (checked later via planAllocation) — accounts
    // can exist in the database without ever having a live adapter
    // connected (see AccountRegistry), which is the common Phase 0/1
    // situation and deserves its own message rather than looking like a
    // capacity problem.
    const anyLiveEnabledAccount = deps.registry.all().some((a) => a.enabled);
    if (!anyLiveEnabledAccount) {
      return reply.code(409).send({
        error: "no_connected_accounts",
        message:
          "No provider accounts have a live connection right now. Accounts you've " +
          "added are recorded, but each one needs a working provider adapter " +
          "(not built yet for any provider in this build) or to be enabled " +
          "before files can be routed to it.",
      });
    }

    const multipartFile = await request.file();
    if (!multipartFile) {
      return reply.code(400).send({ error: "No file provided in multipart form" });
    }

    const compressionOverride = compressionOverrideSchema.parse(
      (multipartFile.fields.compression as { value?: string } | undefined)?.value,
    );
    const settings = settingsRepo.get();
    const compressionUsed: CompressionAlgo =
      compressionOverride ?? settings.defaultCompression;

    const fileUuid = randomUUID();
    const originalStagePath = join(TMP_UPLOADS_DIR, `${fileUuid}.original`);
    const compressedStagePath = join(TMP_UPLOADS_DIR, `${fileUuid}.compressed`);

    // Step 1-2: stream to disk while hashing the original bytes.
    const hash = createHash("sha256");
    multipartFile.file.on("data", (chunk: Buffer) => hash.update(chunk));
    await pipeline(multipartFile.file, createWriteStream(originalStagePath));
    const sha256Original = hash.digest("hex");

    const originalBuffer = await readFile(originalStagePath);
    const fileSize = originalBuffer.length;

    // Step 3: compress.
    const compressedBuffer = await compress(originalBuffer, compressionUsed);
    await pipeline(
      (async function* () {
        yield compressedBuffer;
      })(),
      createWriteStream(compressedStagePath),
    );

    fileRepo.upsertFile({
      fileUuid,
      fileName: multipartFile.filename,
      fileSize,
      compressedSize: compressedBuffer.length,
      compressionUsed,
      successfullyStoredSize: 0,
      fileUploadDate: new Date().toISOString(),
      status: "uploading",
      sha256Original,
    });

    // Step 4: rank accounts (auto-refresh if stale).
    const liveAccounts = deps.registry.all();
    const staleThreshold = Date.now() - settings.stalenessThresholdMs;
    const needsRefresh = liveAccounts.some((a) => {
      const record = providerRepo.get(a.identity.providerName, a.identity.accountIndex);
      if (!record?.lastProbedAt) return true;
      return new Date(record.lastProbedAt).getTime() < staleThreshold;
    });
    deps.priorityManager.setAccounts(liveAccounts);
    if (needsRefresh) await deps.priorityManager.refreshAll();
    const rankedAccounts = deps.priorityManager.getRankedAccounts();

    // Step 5: overflow-fill allocation — abort before any network call if
    // there isn't enough total free space.
    const allocation = await planAllocation(rankedAccounts, compressedBuffer.length);
    if (!allocation.success) {
      fileRepo.upsertFile({
        fileUuid,
        fileName: multipartFile.filename,
        fileSize,
        compressedSize: compressedBuffer.length,
        compressionUsed,
        successfullyStoredSize: 0,
        fileUploadDate: new Date().toISOString(),
        status: "failed",
        sha256Original,
      });
      return reply.code(422).send({
        error: "Insufficient total free space across configured accounts",
        unplacedBytes: allocation.unplacedBytes,
        accountsTried: allocation.accountsTried,
      });
    }

    const fragments = segmentsToFragments(fileUuid, allocation.segments);
    for (const fragment of fragments) fileRepo.upsertFragment(fragment);

    // Steps 6-8: concurrent store with retry, bounded concurrency.
    const result = await storeFragments(
      allocation.segments,
      fragments,
      async (start, end) => compressedBuffer.subarray(start, end),
      {
        retryMaxAttempts: settings.retryMaxAttempts,
        onFragmentUpdate: (fragment) => {
          fileRepo.upsertFragment(fragment);
          progressBus.publish({ fileUuid, fragment });
        },
      },
    );

    // Step 9: finalize.
    const finalStatus = result.allStored ? "complete" : "partial";
    fileRepo.upsertFile({
      fileUuid,
      fileName: multipartFile.filename,
      fileSize,
      compressedSize: compressedBuffer.length,
      compressionUsed,
      successfullyStoredSize: result.successfullyStoredSize,
      fileUploadDate: new Date().toISOString(),
      status: finalStatus,
      sha256Original,
    });

    await rm(originalStagePath, { force: true });
    if (result.allStored) await rm(compressedStagePath, { force: true });

    return fileRepo.getFile(fileUuid);
  });

  // POST /files/:fileUuid/retry — retry only the failed fragments
  app.post<{ Params: { fileUuid: string } }>(
    "/api/files/:fileUuid/retry",
    async (request, reply) => {
      const { fileUuid } = request.params;
      const file = fileRepo.getFile(fileUuid);
      if (!file) return reply.code(404).send({ error: "File not found" });

      const compressedStagePath = join(TMP_UPLOADS_DIR, `${fileUuid}.compressed`);
      let compressedBuffer: Buffer;
      try {
        compressedBuffer = await readFile(compressedStagePath);
      } catch {
        return reply.code(409).send({
          error:
            "Staged data for this upload is no longer available (the file " +
            "already completed and its temp stage was cleared). Re-upload instead.",
        });
      }

      const settings = settingsRepo.get();
      const result = await retryFailedFragments(
        file.fragments,
        (providerName, accountIndex) => deps.registry.resolve(providerName, accountIndex),
        async (start, end) => compressedBuffer.subarray(start, end),
        {
          retryMaxAttempts: settings.retryMaxAttempts,
          onFragmentUpdate: (fragment) => {
            fileRepo.upsertFragment(fragment);
            progressBus.publish({ fileUuid, fragment });
          },
        },
      );

      const allStored = file.fragments
        .map((f) => result.fragments.find((r) => r.fragmentId === f.fragmentId) ?? f)
        .every((f) => f.status === "stored");

      const storedSize = file.fragments
        .map((f) => result.fragments.find((r) => r.fragmentId === f.fragmentId) ?? f)
        .filter((f) => f.status === "stored")
        .reduce((sum, f) => sum + (f.byteEnd - f.byteStart), 0);

      fileRepo.upsertFile({
        ...file,
        successfullyStoredSize: storedSize,
        status: allStored ? "complete" : "partial",
      });
      if (allStored) await rm(compressedStagePath, { force: true });

      return fileRepo.getFile(fileUuid);
    },
  );

  // GET /files/:fileUuid/download — reassemble and download
  app.get<{ Params: { fileUuid: string } }>(
    "/api/files/:fileUuid/download",
    async (request, reply) => {
      const { fileUuid } = request.params;
      const file = fileRepo.getFile(fileUuid);
      if (!file) return reply.code(404).send({ error: "File not found" });
      if (file.status !== "complete") {
        return reply.code(409).send({
          error: `File is not complete (status: ${file.status}); cannot reassemble.`,
        });
      }

      const chunks: Buffer[] = new Array(file.fragments.length);
      await retrieveFragmentsInOrder(
        file.fragments,
        (providerName, accountIndex) => deps.registry.resolve(providerName, accountIndex),
        (chunk, fragment) => {
          chunks[fragment.index] = chunk;
        },
      );

      const compressedBuffer = Buffer.concat(chunks);
      const originalBuffer = await decompress(compressedBuffer, file.compressionUsed);

      if (file.sha256Original && !verifyIntegrity(originalBuffer, file.sha256Original)) {
        return reply.code(422).send({
          error: "integrity-failed",
          message: "Reassembled file does not match the recorded checksum.",
        });
      }

      reply.header("Content-Disposition", `attachment; filename="${file.fileName}"`);
      reply.header("Content-Type", "application/octet-stream");
      return reply.send(originalBuffer);
    },
  );

  // DELETE /files/:fileUuid — delete file + issue delete calls to every
  // fragment's remote account
  app.delete<{ Params: { fileUuid: string } }>(
    "/api/files/:fileUuid",
    async (request, reply) => {
      const { fileUuid } = request.params;
      const file = fileRepo.getFile(fileUuid);
      if (!file) return reply.code(404).send({ error: "File not found" });

      await Promise.allSettled(
        file.fragments.map(async (fragment) => {
          const account = deps.registry.tryResolve(fragment.providerName, fragment.accountIndex);
          if (account) await account.delete(fragment);
        }),
      );

      fileRepo.deleteFile(fileUuid);
      return reply.code(204).send();
    },
  );
}
