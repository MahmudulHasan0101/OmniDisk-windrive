import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { getDb } from "../../db/client.js";
import { SettingsRepository } from "../../db/repository.js";
import { CredentialVault } from "../../security/credential-vault.js";

const patchSettingsSchema = z.object({
  defaultCompression: z.enum(["none", "zstd", "gzip", "brotli"]).optional(),
  prioritySortMode: z.enum(["speed", "latency", "free_space", "manual"]).optional(),
  chunkSizeBytes: z.number().int().positive().optional(),
  retryMaxAttempts: z.number().int().min(0).optional(),
});

export function registerSettingsRoutes(app: FastifyInstance): void {
  const repo = new SettingsRepository(getDb());

  // GET /settings — current config.json-equivalent contents
  app.get("/api/settings", async () => {
    return repo.get();
  });

  // PATCH /settings — update global settings
  app.patch("/api/settings", async (request) => {
    const patch = patchSettingsSchema.parse(request.body);
    return repo.update(patch);
  });

  // GET /settings/vault-status — powers the Settings page credential vault
  // status line (spec section 11.3). Not in the base REST table in section
  // 10, added here because the UI spec explicitly requires it.
  app.get("/api/settings/vault-status", async () => {
    const vault = new CredentialVault();
    const backend = await vault.getBackend();
    return { backend };
  });
}
