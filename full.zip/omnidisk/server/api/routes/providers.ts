import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { getDb } from "../../db/client.js";
import { ProviderAccountRepository, ProviderAppConfigRepository } from "../../db/repository.js";
import { PROVIDER_REGISTRY, getProviderDefinition } from "../../core/provider-registry.js";
import { CredentialVault } from "../../security/credential-vault.js";
import type { ProviderFieldDef } from "../../core/models.js";
import type { AccountRegistry } from "../../core/account-registry.js";
import type { PriorityManager } from "../../core/priority-manager.js";
import { buildAdapter } from "../../providers/adapter-factory.js";
import { GoogleDriveAccount } from "../../providers/google-drive-account.js";

const fieldPayloadSchema = z.record(z.union([z.string(), z.number(), z.boolean()]));

const patchAccountSchema = z.object({
  label: z.string().optional(),
  enabled: z.boolean().optional(),
  manualPriorityRank: z.number().int().optional(),
});

const refreshPrioritySchema = z.object({
  mode: z.enum(["speed", "latency", "free_space", "manual"]).optional(),
});

/** Server-side defense in depth — the UI already enforces this from the same field defs. */
function findMissingRequiredFields(
  defs: ProviderFieldDef[],
  payload: Record<string, unknown>,
): string[] {
  return defs
    .filter((f) => f.required)
    .filter((f) => payload[f.key] === undefined || payload[f.key] === "")
    .map((f) => f.key);
}

/** Any `*CapGB` field in the submitted payload becomes the account's configuredCapBytes. */
function extractConfiguredCapBytes(payload: Record<string, unknown>): number | undefined {
  const capKey = Object.keys(payload).find((k) => k.endsWith("CapGB"));
  if (!capKey) return undefined;
  const gb = Number(payload[capKey]);
  return Number.isFinite(gb) ? gb * 1024 ** 3 : undefined;
}

export function registerProviderRoutes(
  app: FastifyInstance,
  deps: { registry: AccountRegistry; priorityManager: PriorityManager },
): void {
  const accountRepo = new ProviderAccountRepository(getDb());
  const appConfigRepo = new ProviderAppConfigRepository(getDb());
  const vault = new CredentialVault();

  // GET /providers/catalog — the 14 provider type definitions, powers "Add a provider"
  app.get("/api/providers/catalog", async () => {
    return PROVIDER_REGISTRY;
  });

  // GET /providers/catalog/:providerName/app-config — has this OAuth provider's
  // app-level credential already been saved? Lets the UI skip straight to
  // "Connect" for a 2nd+ account of the same provider type.
  app.get<{ Params: { providerName: string } }>(
    "/api/providers/catalog/:providerName/app-config",
    async (request, reply) => {
      const def = getProviderDefinition(request.params.providerName);
      if (!def) return reply.code(404).send({ error: "Unknown provider type" });
      return { configured: appConfigRepo.exists(def.providerName) };
    },
  );

  // POST /providers/catalog/:providerName/app-config — save app-level fields
  // (client_id/client_secret/...) once per provider type. OAuth providers only.
  app.post<{ Params: { providerName: string } }>(
    "/api/providers/catalog/:providerName/app-config",
    async (request, reply) => {
      const def = getProviderDefinition(request.params.providerName);
      if (!def) return reply.code(404).send({ error: "Unknown provider type" });
      if (def.appLevelFields.length === 0) {
        return reply.code(400).send({
          error: `${def.displayName} has no app-level configuration — connect an account directly.`,
        });
      }

      const payload = fieldPayloadSchema.parse(request.body);
      const missing = findMissingRequiredFields(def.appLevelFields, payload);
      if (missing.length > 0) {
        return reply.code(422).send({ error: "Missing required fields", fields: missing });
      }

      const credentialRef = `${def.providerName}_app`;
      await vault.setCredential(credentialRef, JSON.stringify(payload));
      appConfigRepo.upsert(def.providerName, credentialRef);

      return reply.code(201).send({ saved: true });
    },
  );

  // GET /providers/accounts — every configured account instance + cached stats
  app.get("/api/providers/accounts", async () => {
    return accountRepo.list().map((account) => ({
      ...account,
      connected: deps.registry.tryResolve(account.providerName, account.accountIndex) !== null,
    }));
  });

  // POST /providers/:providerName/connect — OAuth providers: run the consent
  // flow against the saved app-config, create a new account instance on success.
  //
  // NOTE: no concrete provider adapters exist yet (Phase 1+, see README), so
  // there's no real browser/OAuth SDK to hand off to here. This creates the
  // account row and reserves its accountIndex/credentialRef exactly as the
  // real flow will, with a placeholder in place of a refresh token — wiring
  // in `open(consentUrl)` + a local callback listener per provider adapter
  // is the only change needed once that adapter exists.
  app.post<{ Params: { providerName: string } }>(
    "/api/providers/:providerName/connect",
    async (request, reply) => {
      const def = getProviderDefinition(request.params.providerName);
      if (!def) return reply.code(404).send({ error: "Unknown provider type" });
      if (!def.requiresOAuthConnect) {
        return reply.code(400).send({
          error: `${def.displayName} doesn't use OAuth — use POST /api/providers/${def.providerName}/accounts instead.`,
        });
      }
      if (!appConfigRepo.exists(def.providerName)) {
        return reply.code(409).send({
          error: `Save ${def.displayName}'s app-level credentials first (POST /api/providers/catalog/${def.providerName}/app-config).`,
        });
      }

      const payload = fieldPayloadSchema.parse(request.body ?? {});
      const missing = findMissingRequiredFields(def.accountLevelFields, payload);
      if (missing.length > 0) {
        return reply.code(422).send({ error: "Missing required fields", fields: missing });
      }

      const existing = accountRepo.list().filter((a) => a.providerName === def.providerName);
      const accountIndex = existing.length;
      const credentialRef = `${def.providerName}_${accountIndex}_refresh_token`;

      // google_drive now has a concrete adapter: return the real consent
      // URL instead of writing a placeholder, so the caller (AddProviderModal)
      // can open it in a browser. The account row + credential slot are
      // reserved here exactly as before; the refresh token lands via
      // POST /api/providers/google_drive/oauth-callback once consent completes.
      if (def.providerName === "google_drive") {
        const rawAppCredential = await vault.getCredential(appConfigRepo.get(def.providerName)!.credentialRef);
        const googleApp = JSON.parse(rawAppCredential!) as { clientId: string; clientSecret: string };
        await vault.setCredential(credentialRef, JSON.stringify({ status: "pending_oauth_connect" }));
        accountRepo.upsert({
          providerName: def.providerName,
          accountIndex,
          label: typeof payload.label === "string" ? payload.label : undefined,
          authType: def.authType,
          credentialRef,
          avgLatencyMs: 0,
          avgSpeedBps: 0,
          priorityScore: 0,
          enabled: !def.isBilledProvider,
          isLiveQuota: def.liveQuotaSupported,
          isBilledProvider: def.isBilledProvider,
          maxSingleObjectBytes: def.maxSingleObjectBytes,
        });
        reply.code(201);
        return {
          providerName: def.providerName,
          accountIndex,
          label: payload.label,
          consentUrl: GoogleDriveAccount.buildConsentUrl(googleApp),
        };
      }

      // Placeholder for the real OAuth callback's refresh token, for any
      // OAuth provider that still has no concrete adapter (Phase 2+).
      await vault.setCredential(credentialRef, JSON.stringify({ status: "pending_oauth_connect" }));

      accountRepo.upsert({
        providerName: def.providerName,
        accountIndex,
        label: typeof payload.label === "string" ? payload.label : undefined,
        authType: def.authType,
        credentialRef,
        avgLatencyMs: 0,
        avgSpeedBps: 0,
        priorityScore: 0,
        enabled: !def.isBilledProvider,
        isLiveQuota: def.liveQuotaSupported,
        isBilledProvider: def.isBilledProvider,
        maxSingleObjectBytes: def.maxSingleObjectBytes,
      });

      reply.code(201);
      return { providerName: def.providerName, accountIndex, label: payload.label };
    },
  );

  // POST /providers/google_drive/oauth-callback — completes the consent
  // flow started above: exchanges the browser-redirect `code` for a
  // refresh token, saves it, and registers a live adapter immediately.
  app.post<{ Body: { accountIndex: number; code: string } }>(
    "/api/providers/google_drive/oauth-callback",
    async (request, reply) => {
      const { accountIndex, code } = z
        .object({ accountIndex: z.number().int(), code: z.string() })
        .parse(request.body);

      const record = accountRepo.get("google_drive", accountIndex);
      if (!record) return reply.code(404).send({ error: "Account not found" });

      const appConfig = appConfigRepo.get("google_drive");
      if (!appConfig) return reply.code(409).send({ error: "Google Drive app config missing" });
      const rawAppCredential = await vault.getCredential(appConfig.credentialRef);
      const googleApp = JSON.parse(rawAppCredential!) as { clientId: string; clientSecret: string };

      const { refreshToken } = await GoogleDriveAccount.exchangeCodeForTokens(googleApp, code);
      await vault.setCredential(record.credentialRef, JSON.stringify({ refreshToken }));

      const adapter = await buildAdapter(record, vault, appConfigRepo);
      if (adapter) {
        deps.registry.register(adapter);
        deps.priorityManager.setAccounts(deps.registry.all());
        await deps.priorityManager.refreshAll().catch((err) => {
          app.log.warn({ err }, "Initial stats probe failed for newly connected account");
        });
      }

      return { connected: adapter !== null };
    },
  );

  // POST /providers/:providerName/accounts — API-key/basic providers: take the
  // filled accountLevelFields directly and register the new account instance.
  app.post<{ Params: { providerName: string } }>(
    "/api/providers/:providerName/accounts",
    async (request, reply) => {
      const def = getProviderDefinition(request.params.providerName);
      if (!def) return reply.code(404).send({ error: "Unknown provider type" });
      if (def.requiresOAuthConnect) {
        return reply.code(400).send({
          error: `${def.displayName} uses OAuth — use POST /api/providers/${def.providerName}/connect instead.`,
        });
      }

      const payload = fieldPayloadSchema.parse(request.body);
      const missing = findMissingRequiredFields(def.accountLevelFields, payload);
      if (missing.length > 0) {
        return reply.code(422).send({ error: "Missing required fields", fields: missing });
      }

      const existing = accountRepo.list().filter((a) => a.providerName === def.providerName);
      const accountIndex = existing.length;
      const credentialRef = `${def.providerName}_${accountIndex}`;

      await vault.setCredential(credentialRef, JSON.stringify(payload));

      const record = {
        providerName: def.providerName,
        accountIndex,
        label: typeof payload.label === "string" ? payload.label : undefined,
        authType: def.authType,
        credentialRef,
        avgLatencyMs: 0,
        avgSpeedBps: 0,
        priorityScore: 0,
        enabled: !def.isBilledProvider, // billed-provider guardrail: opt-in only
        isLiveQuota: def.liveQuotaSupported,
        isBilledProvider: def.isBilledProvider,
        maxSingleObjectBytes: def.maxSingleObjectBytes,
        configuredCapBytes: extractConfiguredCapBytes(payload),
      };
      accountRepo.upsert(record);

      // Where a concrete adapter exists (MEGA today — see adapter-factory.ts),
      // register it immediately instead of leaving the account "saved but
      // not connected" until the next server restart. Credentials aren't
      // validated with a live call here (that still requires the caller to
      // trigger an actual probe/upload) — a bad password surfaces on first
      // real use, same as the OAuth path's unvalidated refresh token.
      try {
        const adapter = await buildAdapter(record, vault, appConfigRepo);
        if (adapter) {
          deps.registry.register(adapter);
          deps.priorityManager.setAccounts(deps.registry.all());
          await deps.priorityManager.refreshAll().catch((err) => {
            app.log.warn({ err }, "Initial stats probe failed for newly added account");
          });
        }
      } catch (err) {
        app.log.warn({ err, providerName: def.providerName, accountIndex }, "Adapter construction failed");
      }

      reply.code(201);
      return { providerName: def.providerName, accountIndex, label: payload.label };
    },
  );

  // PATCH /providers/accounts/:providerName/:accountIndex
  app.patch<{ Params: { providerName: string; accountIndex: string } }>(
    "/api/providers/accounts/:providerName/:accountIndex",
    async (request, reply) => {
      const { providerName } = request.params;
      const accountIndex = Number(request.params.accountIndex);
      const patch = patchAccountSchema.parse(request.body);

      const existing = accountRepo.get(providerName, accountIndex);
      if (!existing) return reply.code(404).send({ error: "Account not found" });

      const updated = { ...existing, ...patch };
      accountRepo.upsert(updated);

      const liveAccount = deps.registry.tryResolve(providerName, accountIndex);
      if (liveAccount) {
        if (patch.enabled !== undefined) liveAccount.enabled = patch.enabled;
        if (patch.manualPriorityRank !== undefined) {
          liveAccount.manualPriorityRank = patch.manualPriorityRank;
        }
      }

      return { ...updated, connected: liveAccount !== null };
    },
  );

  // DELETE /providers/accounts/:providerName/:accountIndex
  app.delete<{ Params: { providerName: string; accountIndex: string } }>(
    "/api/providers/accounts/:providerName/:accountIndex",
    async (request, reply) => {
      const { providerName } = request.params;
      const accountIndex = Number(request.params.accountIndex);

      if (accountRepo.hasFragments(providerName, accountIndex)) {
        return reply.code(409).send({
          error:
            "Account still has fragments referencing it. Force-delete with " +
            "fragment reassignment isn't available yet — free the account " +
            "by deleting or migrating the affected files first.",
        });
      }

      const record = accountRepo.get(providerName, accountIndex);
      accountRepo.delete(providerName, accountIndex);
      deps.registry.unregister(providerName, accountIndex);
      if (record) await vault.deleteCredential(record.credentialRef).catch(() => {});

      return reply.code(204).send();
    },
  );

  // POST /providers/refresh-priority
  app.post("/api/providers/refresh-priority", async (request) => {
    const body = refreshPrioritySchema.parse(request.body ?? {});
    if (body.mode) deps.priorityManager.setMode(body.mode);

    deps.priorityManager.setAccounts(deps.registry.all());
    await deps.priorityManager.refreshAll();

    return accountRepo.list().map((account) => ({
      ...account,
      connected: deps.registry.tryResolve(account.providerName, account.accountIndex) !== null,
    }));
  });
}
