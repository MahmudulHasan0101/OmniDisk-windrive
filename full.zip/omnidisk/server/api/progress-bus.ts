import { EventEmitter } from "node:events";
import type { FileFragment } from "../core/models.js";

export interface ProgressEvent {
  fileUuid: string;
  fragment: FileFragment;
}

/**
 * Backs the SSE endpoint `/api/files/:fileUuid/progress` (spec section 10)
 * so the UI can show live per-fragment progress bars without polling.
 * Single-process, in-memory — fine for a local single-user app (spec
 * section 2 non-goals).
 */
class ProgressBus extends EventEmitter {
  publish(event: ProgressEvent): void {
    this.emit(event.fileUuid, event.fragment);
  }

  subscribe(fileUuid: string, listener: (fragment: FileFragment) => void): () => void {
    this.on(fileUuid, listener);
    return () => this.off(fileUuid, listener);
  }
}

export const progressBus = new ProgressBus();
progressBus.setMaxListeners(50);
