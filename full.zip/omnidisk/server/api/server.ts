import Fastify from "fastify";
import cors from "@fastify/cors";
import multipart from "@fastify/multipart";
import sensible from "@fastify/sensible";
import cron from "node-cron";
import { getDb } from "../db/client.js";
import { SettingsRepository, ProviderAccountRepository, ProviderAppConfigRepository } from "../db/repository.js";
import { AccountRegistry } from "../core/account-registry.js";
import { PriorityManager } from "../core/priority-manager.js";
import { CredentialVault } from "../security/credential-vault.js";
import { buildAdapter } from "../providers/adapter-factory.js";
import { registerProviderRoutes } from "./routes/providers.js";
import { registerFileRoutes } from "./routes/files.js";
import { registerStatsRoutes } from "./routes/stats.js";
import { registerSettingsRoutes } from "./routes/settings.js";

export interface BuildAppOptions {
  /** Allow the app to bind beyond localhost. Defaults to false (spec section 9). */
  allowExternalNetwork?: boolean;
}

export async function buildApp(options: BuildAppOptions = {}) {
  const app = Fastify({ logger: true });

  await app.register(sensible);
  await app.register(multipart, {
    limits: { fileSize: 50 * 1024 * 1024 * 1024 }, // 50GB ceiling; real limit is total free space
  });
  await app.register(cors, {
    origin: options.allowExternalNetwork ? true : ["http://localhost:5173"],
  });

  const db = getDb();
  const settings = new SettingsRepository(db).get();

  const registry = new AccountRegistry();
  const accountRepo = new ProviderAccountRepository(db);
  const appConfigRepo = new ProviderAppConfigRepository(db);

  // Persists every probe's fresh stats back to the DB row, so the dashboard
  // (which reads accountRepo.list(), not live adapters) reflects real
  // numbers instead of staying at whatever was there when the account was
  // first added (previously nothing wired this callback at all, so a
  // connected+probed account could still show "0 B / unknown" forever).
  const priorityManager = new PriorityManager(
    registry.all(),
    settings.prioritySortMode,
    async (account, stats) => {
      const existing = accountRepo.get(account.identity.providerName, account.identity.accountIndex);
      if (!existing) return;
      accountRepo.upsert({
        ...existing,
        totalSpace: stats.totalSpace,
        usedSpace: stats.usedSpace,
        avgLatencyMs: stats.avgLatencyMs,
        avgSpeedBps: stats.avgSpeedBps,
        priorityScore: stats.priorityScore,
        lastProbedAt: stats.lastProbedAt,
      });
    },
  );

  // Reconnect every saved account that has a concrete adapter (Phase 1+;
  // see providers/adapter-factory.ts). Accounts for providers without an
  // adapter yet, or with an incomplete/pending credential, are silently
  // skipped and stay "not connected" — same behavior as today, just now
  // some accounts actually come back online across restarts.
  const vault = new CredentialVault();
  for (const record of accountRepo.list()) {
    try {
      const adapter = await buildAdapter(record, vault, appConfigRepo);
      if (adapter) registry.register(adapter);
    } catch (err) {
      app.log.warn(
        { err, providerName: record.providerName, accountIndex: record.accountIndex },
        "Failed to reconnect saved provider account on startup",
      );
    }
  }
  priorityManager.setAccounts(registry.all());
  // Populate real total/used/free space immediately on boot rather than
  // waiting up to 30 minutes for the next scheduled refresh (below) or for
  // an upload to trigger the staleness check.
  await priorityManager.refreshAll().catch((err) => {
    app.log.warn({ err }, "Initial priority refresh failed");
  });

  registerProviderRoutes(app, { registry, priorityManager });
  registerFileRoutes(app, { registry, priorityManager });
  registerStatsRoutes(app);
  registerSettingsRoutes(app);

  // Periodic priority refresh, per spec section 7: default every 30 min.
  cron.schedule("*/30 * * * *", async () => {
    priorityManager.setAccounts(registry.all());
    try {
      await priorityManager.refreshAll();
    } catch (err) {
      app.log.error({ err }, "Scheduled priority refresh failed");
    }
  });

  return { app, registry, priorityManager };
}
