import type { ProviderAccountBase } from "./provider-account-base.js";
import type { PrioritySortMode, ProviderAccountStats } from "./models.js";

/** Callback invoked with fresh probe results so the caller can persist them. */
export type ProbeResultHandler = (
  account: ProviderAccountBase,
  stats: ProviderAccountStats,
) => void | Promise<void>;

export class PriorityManager {
  constructor(
    private accounts: ProviderAccountBase[],
    private mode: PrioritySortMode = "speed",
    private onProbeResult?: ProbeResultHandler,
  ) {}

  setMode(mode: PrioritySortMode): void {
    this.mode = mode;
  }

  getMode(): PrioritySortMode {
    return this.mode;
  }

  setAccounts(accounts: ProviderAccountBase[]): void {
    this.accounts = accounts;
  }

  /**
   * Probes every enabled account in parallel: pingLatency() +
   * measureThroughput(). Persists results via onProbeResult (caller writes
   * to provider_accounts: avg_latency_ms, avg_speed_bps, last_probed_at).
   * Recomputes priorityScore per the active sort mode.
   */
  async refreshAll(): Promise<void> {
    const enabledAccounts = this.accounts.filter((a) => a.enabled);

    await Promise.all(
      enabledAccounts.map(async (account) => {
        const [latencyMs, speedBps, accountStats] = await Promise.all([
          account.pingLatency(),
          account.measureThroughput(),
          account.getStats(), // totalSpace/usedSpace/freeSpace together, per-adapter
        ]);

        const stats: ProviderAccountStats = {
          ...accountStats,
          avgLatencyMs: latencyMs,
          avgSpeedBps: speedBps,
          lastProbedAt: new Date().toISOString(),
        };

        account.priorityScore = this.computeScore(stats);
        stats.priorityScore = account.priorityScore;

        await this.onProbeResult?.(account, stats);
      }),
    );
  }

  private computeScore(stats: ProviderAccountStats): number {
    switch (this.mode) {
      case "speed":
        return stats.avgSpeedBps;
      case "latency":
        return -stats.avgLatencyMs; // lower latency = higher score
      case "free_space":
        return stats.freeSpace;
      case "manual":
        return 0; // ignored; manual order used directly
    }
  }

  /**
   * Ranked, enabled accounts in priority order. In "manual" mode, sorts by
   * each account's `manualPriorityRank` ascending (unset ranks sort last,
   * in original array order, as a safe default).
   */
  getRankedAccounts(): ProviderAccountBase[] {
    const enabledAccounts = this.accounts.filter((a) => a.enabled);

    if (this.mode === "manual") {
      return [...enabledAccounts].sort((a, b) => {
        const rankA = a.manualPriorityRank ?? Number.POSITIVE_INFINITY;
        const rankB = b.manualPriorityRank ?? Number.POSITIVE_INFINITY;
        return rankA - rankB;
      });
    }

    return [...enabledAccounts].sort(
      (a, b) => b.priorityScore - a.priorityScore,
    );
  }
}
