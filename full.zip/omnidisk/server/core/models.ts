/**
 * Core data model shared across the router, priority manager, provider
 * adapters, and API layer. Mirrors the SQLite schema in db/schema.sql —
 * keep the two in sync when either changes.
 */

export type CompressionAlgo = "none" | "zstd" | "gzip" | "brotli";
export type FragmentStatus = "pending" | "stored" | "failed";
export type FileStatus =
  | "pending"
  | "uploading"
  | "complete"
  | "partial"
  | "failed"
  | "deleted";
export type PrioritySortMode = "speed" | "latency" | "free_space" | "manual";
export type AuthType = "oauth2" | "api_key" | "basic";

export interface FileFragment {
  fragmentId: string; // `${fileUuid}_${providerName}_${accountIndex}_${index}`
  fileUuid: string;
  providerName: string; // e.g. "google_drive", "onedrive", "s3"
  accountIndex: number; // disambiguates multiple accounts of same provider
  byteStart: number; // offset within the post-compression byte stream
  byteEnd: number; // exclusive end offset
  index: number; // global ordering across the whole file (0..n)
  remotePath: string; // fileUuid + '/' + providerName + '_' + accountIndex
  checksum?: string; // sha256 of the fragment's stored bytes
  status: FragmentStatus;
  retryCount: number;
  lastError?: string;
}

export interface OmniFile {
  fileUuid: string;
  fileName: string;
  fileSize: number; // original size, pre-compression
  compressedSize?: number; // size of the byte stream actually fragmented
  compressionUsed: CompressionAlgo;
  successfullyStoredSize: number; // sum of stored fragment byte ranges
  fileUploadDate: string; // ISO 8601
  fragments: FileFragment[]; // ordered by `index`
  status: FileStatus;
  sha256Original?: string; // checksum of the pre-compression file
}

export interface ProviderAccountIdentity {
  providerName: string;
  accountIndex: number;
  label?: string; // user-facing nickname, e.g. "Drive – Work"
}

export interface ProviderAccountStats {
  totalSpace: number;
  usedSpace: number;
  freeSpace: number;
  fragmentCount: number;
  avgLatencyMs: number;
  avgSpeedBps: number;
  lastProbedAt: string;
  priorityScore: number;
  enabled: boolean;
}

export interface ProviderAccountRecord extends ProviderAccountIdentity {
  baseUrl?: string;
  authType: AuthType;
  credentialRef: string; // key into credentials.enc / keytar entry name
  totalSpace?: number;
  usedSpace?: number;
  avgLatencyMs: number;
  avgSpeedBps: number;
  priorityScore: number;
  manualPriorityRank?: number; // used only when sort mode = manual
  enabled: boolean;
  lastProbedAt?: string;
  // --- catalog metadata, mirrored from ProviderDefinition at creation time ---
  isLiveQuota: boolean; // false => freeSpace derives from configuredCapBytes - usedSpace
  isBilledProvider: boolean; // true for S3/Azure/GCS; new accounts default enabled=false
  configuredCapBytes?: number; // user-set ceiling, used when isLiveQuota is false
  maxSingleObjectBytes?: number; // e.g. Box 250MB, GitHub 90MB; undefined = no cap
  // --- runtime-only, not persisted: is there a live adapter for this account
  // in this process's AccountRegistry right now? Populated by the API layer,
  // not the repository — a DB row can exist (registered) without ever having
  // a live adapter (connected) until a Phase 1+ provider adapter exists.
  connected?: boolean;
}

// ---------------------------------------------------------------------------
// Provider registry / catalog — drives the data-driven "Add a provider" UI.
// See companion doc OmniDisk_Provider_Registry_UI_Spec.md for the full spec.
// ---------------------------------------------------------------------------

export type ProviderFieldType = "text" | "password" | "url" | "select" | "number";

export interface ProviderFieldDef {
  key: string; // maps to a key in the credential payload sent to the API
  label: string;
  type: ProviderFieldType;
  placeholder?: string;
  required: boolean;
  helpText?: string; // short inline hint, links back to the setup guide section
  options?: { value: string; label: string }[]; // for type: "select"
  default?: string | number;
  secret?: boolean; // true = mask input, store only in credential vault, never echo back to UI
}

export interface ProviderDefinition {
  providerName: string; // stable id, e.g. "google_drive"
  displayName: string;
  logoUrl: string;
  authType: AuthType;

  // --- capacity/behavior metadata, drives router + UI badges ---
  freeTierLabel: string; // "15 GB", "~10 GB", "Billed (no free tier)"
  liveQuotaSupported: boolean; // can getStorableSpace() be queried live?
  maxSingleObjectBytes?: number; // e.g. Box 250_000_000, GitHub 100_000_000
  isBilledProvider: boolean; // true for S3/Azure/GCS -> excluded from default priority list, opt-in only
  setupGuideAnchor: string; // deep link into the setup guide doc

  // --- form schema ---
  appLevelFields: ProviderFieldDef[]; // empty array for non-OAuth providers
  accountLevelFields: ProviderFieldDef[]; // for OAuth providers this may be just [{ key: "label", ... }]
  requiresOAuthConnect: boolean; // if true, show a "Connect with <Provider>" button after account-level fields
}

export interface ProviderAppConfigRecord {
  providerName: string;
  credentialRef: string;
  createdAt: string;
}

export interface GlobalSettings {
  defaultCompression: CompressionAlgo;
  prioritySortMode: PrioritySortMode;
  chunkSizeBytes: number; // default 8MB, see AllocationPlan
  retryMaxAttempts: number; // default 3
  stalenessThresholdMs: number; // default 10 min, triggers auto-refresh before upload
}

export const DEFAULT_SETTINGS: GlobalSettings = {
  defaultCompression: "zstd",
  prioritySortMode: "speed",
  chunkSizeBytes: 8 * 1024 * 1024, // 8MB, per spec section 15 open decision #4
  retryMaxAttempts: 3,
  stalenessThresholdMs: 10 * 60 * 1000,
};
