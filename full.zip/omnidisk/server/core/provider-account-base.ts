import type {
  FileFragment,
  ProviderAccountIdentity,
  ProviderAccountStats,
} from "./models.js";

/**
 * Contract every provider account must fulfill. No concrete provider is
 * implemented at the skeleton stage — concrete classes (GoogleDriveAccount,
 * OneDriveAccount, S3CompatibleAccount for S3/R2/B2, etc.) extend this in
 * a later phase (see providers/, added incrementally). Adding a new
 * provider never touches the router, priority manager, or API layer.
 */
export abstract class ProviderAccountBase {
  abstract readonly identity: ProviderAccountIdentity;
  abstract readonly baseUrl: string;

  abstract getStorableSpace(): Promise<number>;
  abstract store(fragment: FileFragment, data: Buffer): Promise<FileFragment>;
  abstract retrieve(fragment: FileFragment): Promise<Buffer>;
  abstract delete(fragment: FileFragment): Promise<void>;
  abstract pingLatency(): Promise<number>; // ms, round trip to a lightweight endpoint
  abstract measureThroughput(): Promise<number>; // bytes/sec, small sample upload/download

  priorityScore = 0;
  enabled = true;
  manualPriorityRank?: number; // used only when PrioritySortMode = "manual"

  async getStats(): Promise<ProviderAccountStats> {
    const free = await this.getStorableSpace();
    return {
      totalSpace: 0, // filled from provider-reported quota where available
      usedSpace: 0,
      freeSpace: free,
      fragmentCount: 0, // filled from DB aggregate, not computed here
      avgLatencyMs: 0,
      avgSpeedBps: 0,
      lastProbedAt: new Date().toISOString(),
      priorityScore: this.priorityScore,
      enabled: this.enabled,
    };
  }
}
