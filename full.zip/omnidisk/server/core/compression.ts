import { gzip, gunzip, brotliCompress, brotliDecompress } from "node:zlib";
import { promisify } from "node:util";
import type { CompressionAlgo } from "./models.js";

const gzipAsync = promisify(gzip);
const gunzipAsync = promisify(gunzip);
const brotliCompressAsync = promisify(brotliCompress);
const brotliDecompressAsync = promisify(brotliDecompress);

/**
 * @mongodb-js/zstd is a native binding and an optional dependency (see
 * server/package.json). It's loaded lazily so the rest of the server
 * works even on platforms where the native build is unavailable — in
 * that case, requesting "zstd" throws a clear, actionable error instead
 * of crashing at import time.
 */
async function loadZstd(): Promise<{
  compress: (input: Buffer, level?: number) => Promise<Buffer>;
  decompress: (input: Buffer) => Promise<Buffer>;
}> {
  try {
    const mod = await import("@mongodb-js/zstd");
    return mod;
  } catch (err) {
    throw new Error(
      "zstd compression requested but @mongodb-js/zstd native binding is not available " +
        "on this platform. Choose a different compression algorithm, or install the " +
        "package for a supported OS/arch. Original error: " +
        (err instanceof Error ? err.message : String(err)),
    );
  }
}

const ZSTD_DEFAULT_LEVEL = 3; // best speed/ratio tradeoff at low levels, per spec section 3

export async function compress(
  data: Buffer,
  algo: CompressionAlgo,
): Promise<Buffer> {
  switch (algo) {
    case "none":
      return data;
    case "gzip":
      return gzipAsync(data);
    case "brotli":
      return brotliCompressAsync(data);
    case "zstd": {
      const zstd = await loadZstd();
      return zstd.compress(data, ZSTD_DEFAULT_LEVEL);
    }
  }
}

export async function decompress(
  data: Buffer,
  algo: CompressionAlgo,
): Promise<Buffer> {
  switch (algo) {
    case "none":
      return data;
    case "gzip":
      return gunzipAsync(data);
    case "brotli":
      return brotliDecompressAsync(data);
    case "zstd": {
      const zstd = await loadZstd();
      return zstd.decompress(data);
    }
  }
}
