import { describe, it, expect } from "vitest";
import { createHash, randomBytes } from "node:crypto";
import {
  planAllocation,
  segmentsToFragments,
  storeFragments,
  retrieveFragmentsInOrder,
  verifyIntegrity,
} from "../../server/core/fragment-router.js";
import { compress, decompress } from "../../server/core/compression.js";
import { PriorityManager } from "../../server/core/priority-manager.js";
import { AccountRegistry } from "../../server/core/account-registry.js";
import { MockProviderAccount } from "../helpers/mock-provider-account.js";

describe("Integration: full upload -> fragment -> store -> retrieve -> download cycle", () => {
  it("reconstructs the original file byte-for-byte, split across 3 mock accounts", async () => {
    // Simulate a file too large for any single account's free space, so it
    // must spill across three — this is the scenario the spec calls out
    // explicitly (a big file across several small free-tier accounts).
    const original = randomBytes(300_000);
    const sha256Original = createHash("sha256").update(original).digest("hex");

    const registry = new AccountRegistry();
    const accounts = [
      new MockProviderAccount({ providerName: "drive", freeSpace: 120_000, speedBps: 5000 }),
      new MockProviderAccount({ providerName: "onedrive", freeSpace: 120_000, speedBps: 4000 }),
      new MockProviderAccount({ providerName: "dropbox", freeSpace: 120_000, speedBps: 3000 }),
    ];
    for (const account of accounts) registry.register(account);

    const priorityManager = new PriorityManager(registry.all(), "speed");
    await priorityManager.refreshAll();
    const ranked = priorityManager.getRankedAccounts();

    // --- Upload pipeline ---
    const compressed = await compress(original, "gzip");
    const allocation = await planAllocation(ranked, compressed.length);
    expect(allocation.success).toBe(true);
    expect(allocation.segments.length).toBeGreaterThanOrEqual(2); // must have spilled over

    const fileUuid = "test-file-uuid";
    const fragments = segmentsToFragments(fileUuid, allocation.segments);

    const storeResult = await storeFragments(
      allocation.segments,
      fragments,
      async (start, end) => compressed.subarray(start, end),
    );
    expect(storeResult.allStored).toBe(true);
    expect(storeResult.fragments.every((f) => f.status === "stored")).toBe(true);

    // --- Download pipeline ---
    const chunks: Buffer[] = new Array(storeResult.fragments.length);
    await retrieveFragmentsInOrder(
      storeResult.fragments,
      (providerName, accountIndex) => registry.resolve(providerName, accountIndex),
      (chunk, fragment) => {
        chunks[fragment.index] = chunk;
      },
    );

    const reassembledCompressed = Buffer.concat(chunks);
    expect(Buffer.compare(reassembledCompressed, compressed)).toBe(0);

    const reassembledOriginal = await decompress(reassembledCompressed, "gzip");
    expect(Buffer.compare(reassembledOriginal, original)).toBe(0);
    expect(verifyIntegrity(reassembledOriginal, sha256Original)).toBe(true);
  });

  it("marks the file partial and surfaces a retryable fragment on transient store failure", async () => {
    const original = randomBytes(1000);

    const flaky = new MockProviderAccount({
      providerName: "flaky",
      freeSpace: 1000,
      failFirstNStores: 5, // exceeds default retryMaxAttempts of 3
    });
    const registry = new AccountRegistry();
    registry.register(flaky);

    const allocation = await planAllocation([flaky], original.length);
    expect(allocation.success).toBe(true);

    const fragments = segmentsToFragments("flaky-file", allocation.segments);
    const result = await storeFragments(
      allocation.segments,
      fragments,
      async (start, end) => original.subarray(start, end),
      { retryMaxAttempts: 3 },
    );

    expect(result.allStored).toBe(false);
    expect(result.fragments[0]!.status).toBe("failed");
    expect(result.fragments[0]!.retryCount).toBe(3);
  });

  it("reports insufficient space and never calls store when accounts can't fit the file", async () => {
    const original = randomBytes(500);
    const tiny = new MockProviderAccount({ providerName: "tiny", freeSpace: 100 });

    let storeCalls = 0;
    const originalStore = tiny.store.bind(tiny);
    tiny.store = async (...args) => {
      storeCalls++;
      return originalStore(...args);
    };

    const allocation = await planAllocation([tiny], original.length);
    expect(allocation.success).toBe(false);
    expect(allocation.unplacedBytes).toBe(400);
    expect(storeCalls).toBe(0); // aborted before any network call, per spec section 8
  });
});
