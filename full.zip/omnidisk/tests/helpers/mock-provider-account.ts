import { ProviderAccountBase } from "../../server/core/provider-account-base.js";
import type {
  FileFragment,
  ProviderAccountIdentity,
} from "../../server/core/models.js";

export interface MockAccountOptions {
  providerName: string;
  accountIndex?: number;
  freeSpace: number;
  latencyMs?: number;
  speedBps?: number;
  /** If true, every store() call fails until this many attempts have been made. */
  failFirstNStores?: number;
}

/**
 * In-memory ProviderAccountBase used by unit/integration tests, per spec
 * section 13 ("mock ProviderAccountBase implementations with fixed
 * free-space values" / "in-memory mock provider accounts, no real network
 * calls in CI").
 */
export class MockProviderAccount extends ProviderAccountBase {
  readonly identity: ProviderAccountIdentity;
  readonly baseUrl = "mock://local";

  private storage = new Map<string, Buffer>();
  private freeSpace: number;
  private latencyMs: number;
  private speedBps: number;
  private failFirstNStores: number;
  private storeAttempts = new Map<string, number>();

  constructor(options: MockAccountOptions) {
    super();
    this.identity = {
      providerName: options.providerName,
      accountIndex: options.accountIndex ?? 0,
    };
    this.freeSpace = options.freeSpace;
    this.latencyMs = options.latencyMs ?? 10;
    this.speedBps = options.speedBps ?? 10_000_000;
    this.failFirstNStores = options.failFirstNStores ?? 0;
  }

  async getStorableSpace(): Promise<number> {
    return this.freeSpace;
  }

  async store(fragment: FileFragment, data: Buffer): Promise<FileFragment> {
    const attempts = (this.storeAttempts.get(fragment.fragmentId) ?? 0) + 1;
    this.storeAttempts.set(fragment.fragmentId, attempts);

    if (attempts <= this.failFirstNStores) {
      throw new Error(`Simulated transient failure (attempt ${attempts})`);
    }

    this.storage.set(fragment.remotePath, data);
    this.freeSpace -= data.length;
    return fragment;
  }

  async retrieve(fragment: FileFragment): Promise<Buffer> {
    const data = this.storage.get(fragment.remotePath);
    if (!data) throw new Error(`No stored data for ${fragment.remotePath}`);
    return data;
  }

  async delete(fragment: FileFragment): Promise<void> {
    this.storage.delete(fragment.remotePath);
  }

  async pingLatency(): Promise<number> {
    return this.latencyMs;
  }

  async measureThroughput(): Promise<number> {
    return this.speedBps;
  }
}
