import { describe, it, expect } from "vitest";
import { compress, decompress } from "../../server/core/compression.js";
import type { CompressionAlgo } from "../../server/core/models.js";

const sample = Buffer.from(
  "OmniDisk fragments this text across many provider accounts. ".repeat(200),
  "utf-8",
);

describe("compression roundtrip", () => {
  it.each<CompressionAlgo>(["none", "gzip", "brotli"])(
    "compress -> decompress is byte-for-byte identity for %s",
    async (algo) => {
      const compressed = await compress(sample, algo);
      const decompressed = await decompress(compressed, algo);
      expect(Buffer.compare(decompressed, sample)).toBe(0);
    },
  );

  it("gzip and brotli actually shrink repetitive input", async () => {
    const gzipped = await compress(sample, "gzip");
    const brotlied = await compress(sample, "brotli");
    expect(gzipped.length).toBeLessThan(sample.length);
    expect(brotlied.length).toBeLessThan(sample.length);
  });

  // zstd depends on the optional native binding (@mongodb-js/zstd). Skipped
  // automatically in environments where it isn't installed/buildable,
  // rather than failing CI on unrelated platforms.
  it("compress -> decompress is byte-for-byte identity for zstd (if available)", async () => {
    try {
      const compressed = await compress(sample, "zstd");
      const decompressed = await decompress(compressed, "zstd");
      expect(Buffer.compare(decompressed, sample)).toBe(0);
    } catch (err) {
      expect((err as Error).message).toMatch(/zstd/i);
    }
  });
});
